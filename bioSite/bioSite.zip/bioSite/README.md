# CSD 340 Web Development with HTML and CSS
## Contributors
* Instructor: Adam Bailey
* Student: Jose Franco
